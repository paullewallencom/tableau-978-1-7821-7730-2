## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/building-interactive-dashboards-with-tableau-video/9781782177302)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Building-Interactive-Dashboards-with-Tableau
Building Interactive Dashboards with Tableau, Published by Packt
